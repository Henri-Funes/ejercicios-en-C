# 2D-alg
examen 2 de algoritmos graficos

para compilar gcc ./*.c  -o parcial2 -lGL -lGLU -lglut -lm

INTEGRANTES

Boris Henri Funes Peña - fp20008
Luis Israel Ramos Barahona - RB20021
Liliana Elvira Acevedo Herrera - AH21026
Katherine Adriana Ayala Gomez - AG21038